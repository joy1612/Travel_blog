<aside class="sidebar-widget">
    <?php dynamic_sidebar('sidebar_widget'); ?>
</aside>
